#ifndef WM_HTTP_COMPILE_FILES
#define WM_HTTP_COMPILE_FILES
#include "HTTPClient.c"
#include "HTTPClientAuth.c"
#include "HTTPClientString.c"
#include "HTTPClientWrapper.c"
#include "wm_httpclient_task.c"
#endif
