#ifndef UPNPINTTYPES_H
#define UPNPINTTYPES_H

#if !defined(UPNP_USE_BCBPP)

/* Printf format for integers. */
//#include <inttypes.h>

#endif /* !defined(UPNP_USE_BCBPP) */

#endif /* UPNPINTTYPES_H */
